#!/bin/bash

# Configure the DC/OS cli
source /opt/dcos_services/setup_dcos_cli.sh

# Deploy frameworks from DC/OS universe
dcos package install marathon-lb --yes
dcos package install mongodb-replicaset --yes
dcos package install elastic --options=elasticsearch/options.json --yes
dcos package install kibana --yes

# Deploy custom services and frameworkds
source /opt/dcos_services/deploy_service.sh aries/marathon.json aries/env_vars.sh
source /opt/dcos_services/deploy_service.sh baile/marathon.json baile/env_vars.sh
source /opt/dcos_services/deploy_service.sh baile-nginx/marathon.json baile-nginx/env_vars.sh
source /opt/dcos_services/deploy_service.sh cortex/marathon.json cortex/env_vars.sh
source /opt/dcos_services/deploy_service.sh logstash/marathon.json logstash/env_vars.sh
source /opt/dcos_services/deploy_service.sh orion/marathon.json orion/env_vars.sh
source /opt/dcos_services/deploy_service.sh rabbitmq/marathon.json rabbitmq/env_vars.sh
source /opt/dcos_services/deploy_service.sh um-service/marathon.json um-service/env_vars.sh
